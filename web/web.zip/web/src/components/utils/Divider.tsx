import React from 'react';

const Divider: React.FC = () => {
  return <div className="divider" />;
};

export default Divider;
