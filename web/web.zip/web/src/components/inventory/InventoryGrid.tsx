import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Inventory } from '../../typings';
import WeightBar from '../utils/WeightBar';
import InventorySlot from './InventorySlot';
import { getTotalWeight } from '../../helpers';
import { useAppSelector } from '../../store';
import { useIntersection } from '../../hooks/useIntersection';

const PAGE_SIZE = 30;

const InventoryGrid: React.FC<{ inventory: Inventory }> = ({ inventory }) => {
  const weight = useMemo(
    () => (inventory.maxWeight !== undefined ? Math.floor(getTotalWeight(inventory.items) * 1000) / 1000 : 0),
    [inventory.maxWeight, inventory.items]
  );
  const [page, setPage] = useState(0);
  const containerRef = useRef(null);
  const { ref, entry } = useIntersection({ threshold: 0.5 });
  const isBusy = useAppSelector((state) => state.inventory.isBusy);

  useEffect(() => {
    if (entry && entry.isIntersecting) {
      setPage((prev) => ++prev);
    }
  }, [entry]);
  return (
    <>
      <div className="inventory-grid-wrapper" style={{ pointerEvents: isBusy ? 'none' : 'auto' }}>
        <div>
          <div className="inventory-grid-header-wrapper">

            {inventory.maxWeight == 96000 && inventory.type != 'otherplayer' && inventory.type != 'drop' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/player_icon.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'newdrop' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/drop.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'drop' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/drop.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'container' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/stash.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'crafting' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/craft.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'stash' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/stash.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'inspect' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/search.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'otherplayer' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/search.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'shop' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/shopping-basket.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'trunk' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/trunk.png" style={{height: '100px', width: "auto"}}/>
            )}
            {inventory.type == 'glovebox' && (
              <img src="https://r2.fivemanage.com/rPii30Hrz0CTjLJuGZf5d/trunk.png" style={{height: '100px', width: "auto"}}/>
            )}
            <div>
            <p className="player-name">{inventory.label}</p>
            {inventory.maxWeight && (
              <p>
                {weight / 1000}/{inventory.maxWeight / 1000}kg
              </p>
            )}
            </div>
          </div>
          <WeightBar percent={inventory.maxWeight ? (weight / inventory.maxWeight) * 100 : 0} />
        </div>
        <div className="inventory-grid-container" ref={containerRef}>
          <>
            {inventory.items.slice(0, (page + 1) * PAGE_SIZE).map((item, index) => (
              <InventorySlot
                key={`${inventory.type}-${inventory.id}-${item.slot}`}
                item={item}
                ref={index === (page + 1) * PAGE_SIZE - 1 ? ref : null}
                inventoryType={inventory.type}
                inventoryGroups={inventory.groups}
                inventoryId={inventory.id}
              />
            ))}
          </>
        </div>
      </div>
    </>
  );
};

export default InventoryGrid;
